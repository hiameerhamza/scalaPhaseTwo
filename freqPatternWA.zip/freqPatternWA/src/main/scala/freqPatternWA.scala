import scala.collection.mutable.ListBuffer
import scala.io.Source

object freqPatternWA {
  def main(args: Array[String]): Unit = {

    var freqItemSet=new ListBuffer[String]()

    var count = 0
    var a=List( List("Beer", "Nuts", "Diaper"),
      List("Beer", "Coffee", "Diaper"),
      List("Beer", "Diaper", "Eggs"),
      List("Nuts", "Eggs", "Milk"),
      List("Nuts", "Coffee", "Diaper", "Eggs", "Milk")     )

    var distinctItem=a.flatten.distinct.to[ListBuffer]

    var minSupport = 0.5*(a.length.toDouble)


    //println("Given Distinct Items   \n "+distinctItem+"\n\n")
    for(i<-distinctItem){
      count = 0
      for(j<-a){
        if(j.contains(i))
          count+=1
      }
      if(count>=minSupport)
        freqItemSet+=i
    }
    //  println("One Frequent Item List\n"+freqItemSet)
    println("-----------")
    var k=1
    // while(freqItemSet.length!=nul){
    k+=1

    var candidateItems=distinctItem.combinations(k).to[ListBuffer]


    if(candidateItems.length!=0){
      for(i<-candidateItems){

        count=0
        for(j<-a){
          if(i.forall(j.contains)==true) count+=1
        }
        if(count<minSupport)
          candidateItems-=i

      }
    }


    if(candidateItems.length==0){ //if no new k+1 candidates items set exist
      println(freqItemSet) //previous frequent itemsets

    }
    println(candidateItems)

    //pruning       pruning         pruning
    if(candidateItems.length!=0){
      for(p<-candidateItems){
        count==0
        for(search<-p.combinations(k-1).to[ListBuffer])
          if (freqItemSet.contains(search)) count+=1
        if(!(count>=k-1))
          candidateItems-=p
      }
    }




  }



  //  }


}

